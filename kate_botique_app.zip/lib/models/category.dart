class Category {
  int id;
  String name;
  String icon;
  int categoryId;
}
