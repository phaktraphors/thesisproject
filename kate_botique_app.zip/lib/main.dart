import 'package:flutter/material.dart';
import 'package:kate_botique_app/views/app.dart';

void main() {
  runApp(MyApp());
}


